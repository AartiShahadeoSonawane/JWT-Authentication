package com.BookWeb.BookWebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookWebsite {

    public static void main(String[] args) {
        SpringApplication.run(BookWebsite.class, args);
    }

}
